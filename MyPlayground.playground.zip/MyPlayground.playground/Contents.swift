import UIKit

struct Libro{
	var nombre: String
	var anioDePublicacion: Int?
}

let primerLibro = Libro(nombre: "It", anioDePublicacion: 2020)
let segundoLibro = Libro(nombre: "It 2", anioDePublicacion: 0)
let otroLibro = Libro(nombre: "La biblia", anioDePublicacion: 0)
//print(primerLibro.anioDePublicacion)


if primerLibro.anioDePublicacion != nil{
	//print(primerLibro.anioDePublicacion)
}

//Forced
//let variableDesenvuelta = primerLibro.anioDePublicacion!
//print(variableDesenvuelta)

//guard let


func unwrapp(){
	if let _ = primerLibro.anioDePublicacion{
		//print(yesHayVariable)
		//if let nombrelibro = primerlibro.nombre{
		
	}else{
		//print("no hay valor")
	}
	//print(yesHayVariable)
guard let acaHayValor = primerLibro.anioDePublicacion else {return}
	print(acaHayValor)
}

unwrapp()
