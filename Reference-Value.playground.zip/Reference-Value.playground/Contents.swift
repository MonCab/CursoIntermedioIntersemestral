import UIKit


class Student{
	var name: String
	var lastName: String
	var age: Int
	init(name: String, lastName: String, age: Int) {
		self.name = name
		self.lastName = lastName
		self.age = age
	}
}


let firstStudent = Student(name: "Sherry", lastName: "Wilkinson", age: 10)
let secondStudent = firstStudent
secondStudent.name = "Terry"

//print(firstStudent.name)
//print(secondStudent.name)


struct OtherStudent{
	var name: String
	var lastName: String
	var age: Int
	init(name: String, lastName: String, age: Int) {
		self.name = name
		self.lastName = lastName
		self.age = age
	}
}

let thirdStudent = OtherStudent(name: "Fred", lastName: "Weasley", age: 22)
var fourthStudent = thirdStudent

fourthStudent.name = "George"

print(thirdStudent.name)
print(fourthStudent.name)



