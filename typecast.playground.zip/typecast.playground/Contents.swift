import UIKit

class Animal{
	var nombre: String
	init(nombre: String) {
		self.nombre = nombre
	}
}

class Perro: Animal{
	var emoji: String
	init(nombre: String, emoji: String) {
		self.emoji = emoji
		super.init(nombre: nombre)
	}
}

class Gato: Animal {
	var color: String
	init(nombre: String, color: String) {
		self.color = color
		super.init(nombre: nombre)
	}
}

func ladrar (perrito: Perro){
	print(perrito.emoji + "woof")
}

func maullar (gatito: Gato){
	print("Un gatito de color \(gatito.color) hace miau")
}
func esAnimal (animalito : Any){
	if  let perrito = animalito as? Perro{
		print(perrito.nombre + "  es perro")
	}
	if let gatito = animalito as? Gato{
		print(gatito.nombre + " es un gato")
	}
	if let palabra = animalito as? String{
		print("Es un string")
	}
}

var cocoa = Perro(nombre: "Cocoa", emoji: "🐕‍🦺")
var gtito = Gato(nombre: "Michi", color: "Cafe")
esAnimal(animalito: gtito)


/*
if let cocoa2 = cocoa as! Perro?{
	ladrar(perrito: cocoa2)
}
*/

