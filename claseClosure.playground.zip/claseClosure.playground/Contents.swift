import UIKit

func filteredGreaterThanValue(value: Int, numbers: [Int]) -> [Int]{
    var filteredList = [Int]()
    for number in numbers {
        if (number > value){
            filteredList.append(number)
        }
    }
    return filteredList
}

func filtracionConClosure(closure: (Int) ->Bool, arregloDeNumeros: [Int]) -> [Int]{
    var resultado = [Int]()
    for num in arregloDeNumeros{
        if closure(num){
            resultado.append(num)
        }
    }
    return resultado
}

let numeros = [1,2,3,4,5,6,7,8,9,0]

//let ejemplo = filtracionConClosure(closure: { (num) -> Bool in
//    return num < 3
//}, arregloDeNumeros: numeros)

func mayorACinco(num: Int ) -> Bool{
    return num > 5
}
func esPar(num: Int) -> Bool{
    return num % 2 == 0
}
let ejemplo =  filtracionConClosure(closure: mayorACinco, arregloDeNumeros: numeros)
print(ejemplo)
