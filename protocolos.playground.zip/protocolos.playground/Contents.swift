import UIKit

//Codable, Equatable, Printable

protocol descuento{
	func descuentito()
}


class Computadora : CustomStringConvertible, descuento{
	var procesador: String
	var ramEnGB: Int
	var precio: Double
	init(procesador: String, ramEnGB: Int, precio: Double) {
		self.procesador = procesador
		self.ramEnGB = ramEnGB
		self.precio = precio
	}
	var description: String{
		return "Computadora con un \(procesador), y \(ramEnGB) GB de RAM"
	}
	func descuentito() {
		self.precio *= 0.9
	}
	
}

var compu = Computadora(procesador: "i5", ramEnGB: 4, precio: 10000.0)
var otraCompu = Computadora(procesador: "i7", ramEnGB: 8, precio: 15000.0)


print(compu)


struct Estudiante : Equatable{
	var nombre: String
	var apellido: String
	static func == (lhs: Estudiante, rhs: Estudiante) -> Bool{
		return lhs.apellido == rhs.apellido
	}
}

var pepe = Estudiante (nombre: "Paco", apellido: "Perez")
var paco = Estudiante (nombre: "Paco", apellido: "Martinez")


print(pepe == paco)
















