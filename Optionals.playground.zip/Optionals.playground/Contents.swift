 import UIKit

struct Student {
	var name: String
	var middleName: String?
	var lastName: String
}

let estudiante = Student(name: "Montserrat", middleName: nil, lastName: "Caballero")

print(estudiante.middleName!)
